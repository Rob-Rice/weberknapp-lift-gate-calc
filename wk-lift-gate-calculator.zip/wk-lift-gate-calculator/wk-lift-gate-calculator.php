<?php
/**
 * Plugin Name: WK Lift Gate Calculator
 * Description: Adds the lift gate calculator shortcode [wk_lift_gate_calculator].
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: wk-lift-gate-calculator
 */

if (!defined('ABSPATH')) {
    exit;
}

final class WK_Lift_Gate_Calculator_Plugin
{
    const VERSION = '1.0.0';

    public static function boot()
    {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_shortcode('wk_lift_gate_calculator', array(__CLASS__, 'render_shortcode'));
    }

    public static function register_assets()
    {
        wp_register_style(
            'wk-lift-gate-calculator',
            plugins_url('assets/css/calculator.css', __FILE__),
            array(),
            self::VERSION
        );

        wp_register_script(
            'wk-lift-gate-calculator',
            plugins_url('assets/js/calculator.js', __FILE__),
            array(),
            self::VERSION,
            true
        );
    }

    public static function render_shortcode($attributes = array(), $content = null)
    {
        self::register_assets();
        wp_enqueue_style('wk-lift-gate-calculator');
        wp_enqueue_script('wk-lift-gate-calculator');

        ob_start();
        ?>
        <div class="wk-lift-gate-calculator" data-wk-lift-gate-calculator>
            <div class="wk-lift-gate-calculator__header">
                <h2>Integrated Lift Gate Calculator</h2>
                <p>Instructions: Enter lid length, lid weight, and lid offset per customer. The approximated total lid torque will be calculated. The appropriate lift gate assistant will be supplied. If additional weight will be required to utilize the lift gate assistant, it will be shown above the lift gate assistant required, along with the distance from the pivot.</p>
            </div>

            <div class="wk-lift-gate-calculator__grid">
                <section class="wk-lift-gate-calculator__panel" aria-label="Inputs">
                    <h3>Inputs:</h3>
                    <div class="wk-lift-gate-calculator__fields">
                        <label>
                            <span>Enter Lid Length (hinge end to opposite end)</span>
                            <span class="wk-lift-gate-calculator__control">
                                <input name="lidLength" type="number" step="any" value="30" inputmode="decimal">
                                <span>inches</span>
                            </span>
                        </label>
                        <label>
                            <span>Enter Lid Weight</span>
                            <span class="wk-lift-gate-calculator__control">
                                <input name="lidWeight" type="number" step="any" value="35" inputmode="decimal">
                                <span>lbs.</span>
                            </span>
                        </label>
                        <label>
                            <span>Enter Countertop Overhang</span>
                            <span class="wk-lift-gate-calculator__control">
                                <input name="counterTopOverhang" type="number" step="any" value="1" inputmode="decimal">
                                <span>inches</span>
                            </span>
                        </label>
                        <label>
                            <span>Enter Lid Thickness</span>
                            <span class="wk-lift-gate-calculator__control">
                                <input name="lidThickness" type="number" step="any" value="0.5" inputmode="decimal">
                                <span>inches</span>
                            </span>
                        </label>
                    </div>
                </section>

                <section class="wk-lift-gate-calculator__panel wk-lift-gate-calculator__panel--results" aria-label="Calculations and outputs">
                    <h3>Calculations:</h3>
                    <dl class="wk-lift-gate-calculator__results">
                        <div>
                            <dt>Approximate Total Lid Torque</dt>
                            <dd data-output="torque" aria-live="polite">719.505 in-lbs</dd>
                        </div>
                    </dl>

                    <h3>Outputs:</h3>
                    <dl class="wk-lift-gate-calculator__results">
                        <div class="wk-lift-gate-calculator__result--primary">
                            <dt>Recommended Lift Gate Assistant:</dt>
                            <dd data-output="assistant" aria-live="polite">33397-L</dd>
                        </div>
                        <div>
                            <dt>Recommended Lift Gate Stop Size:</dt>
                            <dd data-output="stop">LARGE STOP</dd>
                        </div>
                        <div>
                            <dt>Approx. Torque to Next Models Average Torque:</dt>
                            <dd data-output="nextTorque"></dd>
                        </div>
                        <div>
                            <dt>Approx. Weight to Add to Reach Torque:</dt>
                            <dd data-output="additionalWeight"></dd>
                        </div>
                        <div>
                            <dt>Lift Gate Assistant Recommended for added weight:</dt>
                            <dd data-output="additionalModel"></dd>
                        </div>
                    </dl>
                </section>
            </div>

            <div class="wk-lift-gate-calculator__footer">*Please verify fit using our specification sheet prior to purchase.</div>
        </div>
        <?php
        return ob_get_clean();
    }
}

add_action('init', array('WK_Lift_Gate_Calculator_Plugin', 'boot'));
