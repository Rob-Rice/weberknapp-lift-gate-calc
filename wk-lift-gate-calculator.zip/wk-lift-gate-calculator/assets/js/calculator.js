(function () {
    'use strict';

    var LIMITS = {
        minLength: 30,
        maxLength: 48.001,
        minOverhang: -0.001,
        stopTransition: 0.5001,
        maxOverhang: 1.001,
        minThickness: 0.001,
        maxThickness: 2.001
    };

    var MODELS = [
        { minimum: 1, maximum: 689, name: 'Contact WK' },
        { minimum: 690, maximum: 897, name: '33397-L' },
        { minimum: 897, maximum: 1102, name: '33397-M' },
        { minimum: 1102, maximum: 1325, name: '33397-H' },
        { minimum: 1326, maximum: 6000, name: 'Contact WK' }
    ];

    function formatNumber(value, maximumFractionDigits) {
        return new Intl.NumberFormat('en-US', {
            maximumFractionDigits: maximumFractionDigits === undefined ? 3 : maximumFractionDigits
        }).format(value);
    }

    function calculate(input) {
        var length = Number(input.lidLength);
        var weight = Number(input.lidWeight);
        var overhang = Number(input.overhang);
        var thickness = Number(input.thickness);
        var issue = '';
        var torque;
        var model = '';
        var stop = '';
        var nextTorque = '';
        var additionalWeight = '';
        var additionalModel = '';

        if (![length, weight, overhang, thickness].every(Number.isFinite)) {
            return {
                torque: '—',
                assistant: '—',
                stop: '',
                nextTorque: '',
                additionalWeight: '',
                additionalModel: ''
            };
        }

        if (length < LIMITS.minLength) {
            issue = 'LID TOO SHORT';
        } else if (overhang < LIMITS.minOverhang) {
            issue = 'NOT ENOUGH OVERHANG';
        } else if (thickness < LIMITS.minThickness) {
            issue = 'LID TOO THIN';
        } else if (length > LIMITS.maxLength) {
            issue = 'LID TOO LONG';
        } else if (overhang > LIMITS.maxOverhang) {
            issue = 'TOO MUCH OVERHANG';
        } else if (thickness > LIMITS.maxThickness) {
            issue = 'LID TOO THICK';
        }

        if (issue) {
            return {
                torque: issue,
                assistant: '—',
                stop: issue,
                nextTorque: '',
                additionalWeight: '',
                additionalModel: ''
            };
        }

        if (
            overhang > LIMITS.minOverhang &&
            length < LIMITS.maxLength &&
            overhang < LIMITS.maxOverhang &&
            thickness < LIMITS.maxThickness
        ) {
            torque = (((length / 2) + overhang + 3.043) * weight) + 53;
        } else {
            return {
                torque: 'Contact WK',
                assistant: 'Contact WK',
                stop: getStop(overhang),
                nextTorque: '',
                additionalWeight: '',
                additionalModel: ''
            };
        }

        model = getModel(torque);
        stop = getStop(overhang);

        if (model === 'Contact WK' && torque >= 1 && torque <= 689) {
            var delta = 840 - torque;
            var leverArm = length - 6;
            if (leverArm > 0) {
                nextTorque = formatNumber(delta) + ' in-lbs';
                additionalWeight = formatNumber(Math.abs(delta) / leverArm, 1) +
                    ' lbs. at ' + formatNumber(leverArm, 2) + ' inches';
                additionalModel = '33397-L';
            }
        }

        return {
            torque: formatNumber(torque) + ' in-lbs',
            assistant: model,
            stop: stop,
            nextTorque: nextTorque,
            additionalWeight: additionalWeight,
            additionalModel: additionalModel
        };
    }

    function getModel(torque) {
        for (var i = 0; i < MODELS.length; i += 1) {
            if (torque >= MODELS[i].minimum && torque <= MODELS[i].maximum) {
                return MODELS[i].name;
            }
        }
        return 'No matching model';
    }

    function getStop(overhang) {
        if (overhang > LIMITS.stopTransition) {
            return overhang < LIMITS.maxOverhang ? 'LARGE STOP' : 'TOO MUCH OVERHANG';
        }
        return overhang > LIMITS.minOverhang ? 'SMALL STOP' : 'NOT ENOUGH OVERHANG';
    }

    function readNumber(container, name) {
        var field = container.querySelector('input[name="' + name + '"]');
        if (!field || field.value.trim() === '') {
            return NaN;
        }
        return Number(field.value);
    }

    function update(container) {
        var result = calculate({
            lidLength: readNumber(container, 'lidLength'),
            lidWeight: readNumber(container, 'lidWeight'),
            overhang: readNumber(container, 'counterTopOverhang'),
            thickness: readNumber(container, 'lidThickness')
        });

        Object.keys(result).forEach(function (key) {
            var output = container.querySelector('[data-output="' + key + '"]');
            if (output) {
                output.textContent = result[key];
            }
        });
    }

    function initialize() {
        var calculators = document.querySelectorAll('[data-wk-lift-gate-calculator]');
        calculators.forEach(function (container) {
            container.querySelectorAll('input[type="number"]').forEach(function (field) {
                field.addEventListener('input', function () {
                    update(container);
                });
            });
            update(container);
        });
    }

    window.WKLiftGateCalculator = window.WKLiftGateCalculator || {};
    window.WKLiftGateCalculator.calculate = calculate;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();
