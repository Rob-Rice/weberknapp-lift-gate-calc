WK Lift Gate Calculator
=======================

Install this plugin through WordPress:
1. In WordPress, open Plugins > Add New Plugin > Upload Plugin.
2. Select wk-lift-gate-calculator.zip and install it.
3. If another active plugin already registers this shortcode, deactivate that plugin before activating this one.
4. Activate WK Lift Gate Calculator.

The shortcode remains:
[wk_lift_gate_calculator]

The plugin includes the calculator markup, responsive styling, and browser-side calculations. The initial values (30 in. lid length, 35 lb. weight, 1 in. overhang, and 0.5 in. thickness) produce 719.505 in-lbs, model 33397-L, and LARGE STOP.

Calculator limits and lift-gate torque ranges are based on the supplied workbook's "Inside Only" sheet. Verify fit against the current product specification sheet before purchase.

No connection to a live WordPress site was used to install or test this package.
